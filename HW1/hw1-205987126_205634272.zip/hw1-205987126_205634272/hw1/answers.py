r"""
Use this module to write your answers to the questions in the notebook.

Note: Inside the answer strings you can use Markdown format and also LaTeX
math (delimited with $$).
"""

# ==============
# Part 1 answers

part1_q1 = r"""

1. False. The test set is used to estimate the out-of-sample error (generalization error) of a model.
in-sample error (training error) is the error rate of a model on the training data.
2. False. For example, suppose we have a dataset with 1000 samples and we split it randomly into a train set with 50 samples and a test set with 950 samples.
In this case, the small train set may not be representative of the distribution of the data, and could lead to overfitting.
3. True. The test set is used to evaluate the final model's performance after all the model selection and hyperparameter tuning is done.
During cross-validation, the data is split into k folds, and k-1 folds are used for training and the remaining fold is used for validation.
The test-set is held out for the final evaluation and should not be used for model selection or hyperparameter tuning to prevent data leakage.
4. True. We can use splits to approximate the generalization error. 
"""

part1_q2 = r"""
The approach is not justified, as the model selection process should be performed without using the test set.
Using the test set to select the regularization hyperparameter $\lambda$ could result in overfitting to the test set, which in turn could lead to poor performance on new, unseen data.

Instead, one should use a separate validation set or perform cross-validation to select the best value of $\lambda$.
This approach ensures that the model is not overfitting to the test set and provieds a more realistic estimate to the model's performance on new unseen data.

"""

# ==============
# Part 2 answers

part2_q1 = r"""
Increasing the value of k can lead to improved generalization for unseen data, but this depends on the k. For a small k, the model may overfit as it is sensitive to noise and outliers. Overfitting can impact performance on unseen data because the model may be using noise from the training data to make decisions on unseen data. As k increases the model is better able to handle noise and outlier because more neighbors are used to make a prediction. When more neighbors are used, the generalization is better as the model is less likely to use noise to decide on unseen data. However, when k is too large, the model may start to ignore patterns and meaningful relationships in the data which can also impact performance negatively and underfit. When k becomes too large the model will become biased (in other words the relationship that it is capable of describing is simpler than the true underlying dependence). When bias increases too much, the generalization error will start increasing again. Note, for instance, that in the limiting case of $K=n$ (where n is the total number of observations in the dataset), the KNN model will be always predicting just the mean value (or majority vote if we are doing classification) of all the n outcomes, for any input value.
"""

part2_q2 = r"""
Avoid overfitting in both cases.

1. When a model is trained on the entire train-set and its performance is evaluated on the same set, it may lead to overfitting, where the model **weights** are tailored to the train-set but fails to generalize to unseen data.

2. When selecting the best model based on test-set accuracy, there is a risk that the model is overly tailored to the training and test data.If the model is repeatedly trained on the same data and evaluated on the same data. The chosen **hyperparameters** performs well on the test set, but not necessarily on new, unseen data.

In contrast, k-fold CV helps in avoiding overfitting by providing a more realistic estimate of the model's overall performance (weights and hyperparameters)  on unseen data.

Consider $K=1$ - in this case the model would use the single nearest neighbor to make the prediction. But for an observation X from the training set  it's nearest neighbor is always... itself!! So KNN model with $K=1$ has zero training error (which means that it is bound to overfit if there is any noise in the data...).

"""

# ==============

# ==============
# Part 3 answers

part3_q1 = r"""
The selection of $\Delta > 0$ in the SVM loss function may appear arbitrary at first glance, as it primarily affects the scale of the margin. However, it is crucial to acknowledge that the regularization term, controlled by the regularization weight $\lambda$, plays a significant role in influencing the model's complexity and, subsequently, the margin.

The regularization term aims to encourage a simpler decision boundary by penalizing complex models. By increasing the value of $\lambda$, we emphasize the importance of simplicity, leading to a smoother decision boundary and potentially larger margins. Conversely, decreasing the value of $\lambda$ allows the model to fit the training data more closely, potentially resulting in a more complex decision boundary and smaller margins.

When adjusting the regularization weight $\lambda$, it is not only the absolute change that matters but also the relative change. For example, consider changing $\lambda$ from 1 to 2, resulting in a 2-fold (or 100%) increase in the amount of regularization. In contrast, changing $\lambda$ from 100 to 101 corresponds to only a 1% increase in regularization. In practice, it is often desirable to have a constant or approximately constant percent increase, ensuring a similar multiplier effect on the complexity of the model, regardless of the initial value of $\lambda$.

"""

part3_q2 = r"""
1. The linear model learns a linear decision boundary and attempts to distinguish between different classes. The model in our case is learning the weights of the data which are scanned handwritten digits represented as pixels with varied intensity (representing how light or dark the pixel is). As the model is learning the weights for each pixel, it assigns weights according to relationships and may put more weight to pixels that make up the border of a digit or the center (for example). This can lead to potential classification errors when images are rotated, or if a digit was written at an angle. This can also cause classification errors between digits that share similarities such as 3 and 8 or 5 and 6. 

2. kNN , in general, also tries to identify classes based on a patters in the input data and its features, but kNN does not learn a decision boundary, but runs over many instances and tries to classify them based on their nearest neighbors. KNN does learn a decision boundary at the end: imagine the simplest case of $K=1$. In this case any data point (observation) that is closer to some training observation $X_i$ will be classified as class yi. So if you consider the training points (observation) $X_1, X_2, ..., X_n$, then the whole volume around $X_i$ comprised of points that are closer to Xi then they are to anything else will be uniformly classified as $y_i$. Those volumes will actually form polygons. This is known as Voronoi tesselation. The whole polygon around a point - any observation that falls into that polygon that is, will be classified as the label of the corresponding training point sitting inside that polygon. The union of the boundaries of the polygons that happen to separate different classes will be your bona fide decision boundary. When $K > 1$ the tesselation is much harder to build, but the idea is the same: if I am using $K=5$ and there are 5 nearby training points, 3 of class A and 2 of class B - I can walk around in the neighborhood of those points, while making sure that those 5 points are still the closest to me. That will define a whole area (some sort of a polygon, which in this case may become non-convex I believe) which will all be classified as A (by majority vote).
"""

part3_q3 = r"""
1. We can see that we converge quickly and that the validation and training loss decrease in the same direction which implies that our learning rate is *good*. When the learning rate is set to a high value, the model converges quickly, but it may only reach a local minimum, which may not have the best performance, and the optimization may miss the mininum. A low learning rate takes longer to converge but it may produce better results.

2. Based on the metrics, we can see that as we approach concergence the validation accuracy is lower than training accuracy so there may be some overfitting (slight overfitting).
"""

# ==============

# ==============
# Part 4 answers

part4_q1 = r"""
An ideal residual plot should show randomness, constant variance (homoscedasticity), a mean of zero, and independence. 
Randomness indicates that the model captures the relationship between variables without violating assumptions. 
Constant variance suggests that the spread of residuals is consistent across predicted values. 
A mean of zero indicates unbiased predictions. 
Independence means that residuals at one point do not provide information about residuals at other points. 

Based on the provided residual plots, we can make several observations regarding the fitness of the trained model.
Firstly, the plots indicate that the model performs relatively well in predicting mid and low-priced houses, as the residuals exhibit a good fit in those ranges.
However, there seems to be less accuracy when predicting high-priced houses. 
This discrepancy may be attributed to a limited representation of high prices in the available data, which affects the randomness of the residuals.
Despite this limitation, a positive aspect is that the residuals are centered around a zero mean, suggesting that the model does not suffer from a significant problem of over- or underestimation.

```
fig, axes = plt.subplots(nrows=1, ncols=2, sharey=True, figsize=(20,10))

y_pred = hw1linreg.fit_predict_dataframe(model,  df_boston, 'MEDV', top_feature_names)


plot_residuals(y, y_pred, ax=axes[0])

# calculate residual mean
res = y - y_pred
res_mean = res.mean()

# plot mean line in green
axes[0].hlines(y=res_mean, xmin=y_pred.min(), xmax=y_pred.max(), color='green', lw=3)

# Use the best hyperparameters
model.set_params(**best_hypers)

# Train best model on full training set
y_pred_train, mse, rsq = linreg_boston(model, x_train, y_train)
print(f'train: mse={mse:.2f}, rsq={rsq:.2f}')
ax = plot_residuals(y_train, y_pred_train, ax=axes[1], res_label='train')

# Evaluate on test set
y_pred_test, mse, rsq = linreg_boston(model, x_test, y_test, fit=False)
print(f'test:  mse={mse:.2f}, rsq={rsq:.2f}')
ax = plot_residuals(y_test, y_pred_test, ax=ax, res_label='test')

# plot mean line in green
axes[1].hlines(y=res_mean, xmin=y_pred.min(), xmax=y_pred.max(), color='green', lw=3)

```
In the residual plot we want to see a horizontal band - if there is a nonlinearity in the data that our model does not capture, the band would bend up, or down, or oscilate as we move from left to write, in other words it would have some additional dependence on \hat{y} (the part that our model failed to capture). The rest of what you are saying is correct, we have that band to have approx. constant width across, from left to right (homoscedasticity), and we want it to be centered at zero on vertical axis. Technically, we also want to see normality of the distribution of residuals (ie. vertically) around that zero centerline, but it is hard to see in the residuals plot, QQ plot is better suited for that.
in the earlier residual plots (before adding nonlinearity) you have seen just that: the "band" of the residuals was clearly bent. That's exactly the indication that there are some nonlinearities in the data that our model does not capture


"""

part4_q2 = r"""
Adding non-linear features to the data would result in a model that is no longer a pure linear regression model.
Linear regression assumes a linear relationship between the predictors and the response variable.
By introducing non-linear features, the relationship between the predictors and the response becomes non-linear, making it a form of polynomial regression or non-linear regression.
So, adding non-linear features changes the nature of the regression model.

Yes, by adding non-linear features, we can capture and fit non-linear functions of the original features.
For example, if we have a feature 'x', we can create additional features like 'x^2', 'x^3', or even more complex non-linear transformations like 'sqrt(x)' or 'log(x)'.
These non-linear features allow the model to capture and represent non-linear relationships between the predictors and the response.

```
from sklearn.linear_model import LinearRegression

# Generate a toy dataset with a cubic relationship
x = np.linspace(-10, 10, 100)
y = x**3 + np.random.normal(scale=50, size=100)

# Fit a linear regression model with x^3 as a feature
model = LinearRegression()
X = pd.DataFrame({'x': x, 'x_cubed': x**3})
model.fit(X, y)

# Print the coefficients for x and x^3
print(model.coef_)

# Make predictions on new data
x_new = np.linspace(-15, 15, 100)
X_new = pd.DataFrame({'x': x_new, 'x_cubed': x_new**3})
y_pred = model.predict(X_new)


plt.scatter(x, y)
plt.plot(x_new, y_pred, color='red')
plt.show()
```

In the case of a linear classification model, adding non-linear features would lead to a decision boundary that is no longer a simple hyperplane.
The decision boundary would become a more complex shape, potentially curved or nonlinear, due to the presence of the non-linear features.
This is because the non-linear features introduce additional dimensions and complexity to the model, allowing it to separate classes that may not be linearly separable in the original feature space.
We can think of polynomial features as an additional layer to our model which no longer keeps it a linear model.

Statistical linear models are linear with respect to model coefficients (and that leads to a particular analytical/numerical ways of solving those). Linear models are thus a pretty broad framework. For instance, $Y = a X + b X^2$ is still a LINEAR model. Yes, in order to convey the fact that we are in fact using nonlinear (polynomial in this case) transformations of our original variables (X in this case), we often call it "polynomial regression". Just to be more specific. But is is a linear model nonetheless, 100%. Put differently, linear models do not assume "linear dependence on the features provided in the original data". They assume linear dependence on all the "predictors" (as you said in your answer), but those predictors may include manually built, "engineered" features: e.g. the observations come with a single predictor $X$, but I decided to build a linear model, using $X$, $X^2$ (and maybe X^3*log X, why not!) as my variables. Still linear model.

That's the beauty of it, a pretty simple framework of linear models can describe nonlinear dependencies in the data, we just need to add those non-linearly transformed originally measured variables into the mix of "predictors" we want to use - and we are done, same machinery, same algorithms, same analytical properties, everything we know about linear models still applies.

"""

part4_q3 = r"""
1. This is beneficial for cross-validation as it allows us to explore a wider range of hyperparameter values with a smaller number of samples.
This is particularly useful for regularization parameters like $\lambda$, where the optimal value may lie on a logarithmic scale. 

2. The outer loop iterates over the combinations of degree and $\lambda$, resulting in $d \times l$ iterations.
Within each iteration of the outer loop, the model is fitted $k_{\text{folds}}$ times, where $k_{\text{folds}}$ is the number of folds used for cross-validation.
Therefore, the total number of times the model is fitted is $d \times l \times k_{\text{folds}}$.
There are $d$ degrees and $l$ $\lambda$ values, and $k_{\text{folds}}$ is set to 3, the model will be fitted $d \times l \times 3$ times in total.
degree_range has 3 values and the lambda_range has 20 values, the model will be fitted $3 \times 20 \times 3 = 180$ times in total.
Following cross-validation, the model undergoes a final fine-tuned fit on the complete training set, utilizing the selected hyperparameters.

"""

# ==============
